---
name: Pull Request
about: Contribuindo ao projeto
title: ''
labels: ''

---

**Descreva o objetivo das modificações**
Uma descrição clara do que o código sendo contribuído faz

**Screenshots**
Se aplicável inclua imagens que demonstram a alteração visual no
funcionamento

**Informações adicionais**
Coloque aqui qualquer informação adicional que achar útil


## Licença / Autorização de utilização

(não concluir a contribuição se não estiver de acordo com os termos)

Ao submeter essa contribuição **AUTORIZO** que elas sejam utilizadas
em produtos comerciais derivados do Ticketz OSS única e exclusivamente
por seus autores originais, a saber Claudemir Todo Bom e TODOBOM.COM
Tecnologia da Informação Ltda. Demais derivações que incluam estas
contribuições ficam submetidas à licença original do projeto (GNU
AFFERO GENERAL PUBLIC LICENSE) conforme o arquivo LICENSE.md na raiz
do projeto.
