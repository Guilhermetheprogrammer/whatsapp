export const GitInfo = {
  commitHash: "",
  commitTimestamp: "",
  branchName: "",
  tagName: "v1.0.x",
  buildTimestamp: "custom build"
};
